# Groupdocs Annotation

GroupDocs Annotation plugin for PimCore CMS (Source)

With GroupDocs Annotation plugin for PimCore CMS you can easily [annotate on PDF's](http://groupdocs.com/apps/annotation), Word documents, Excel documents, Powerpoint documents and more with the GroupDocs Annotation tool, directly from within your PimCore CMS powered website.

### Plugin Manual Installation Instructions:

1. Copy plugin files to '/path-to-installed-pimcore/plugins/GroupDocsAnnotation' directory.
2. Login to pimcore as admin
3. Go to "Extras"=>"Extensions"=>"Manage Extensions"
4. Click button "Enamble/Disable" and "Install/Unistall"

### Installation from PimCore CMS:

1. Login to pimcore as admin
2. Go to "Extras"=>"Extensions"=>"Download Extensions"
3. Find GroupDoca Annotation plugin and click "Download" button
3. Go to "Extras"=>"Extensions"=>"Manage Extensions"
4. Click button "Enamble/Disable" and "Install/Unistall"

### GroupDocs Annotation plugin using:


For use plugin add code to your view:
```php
<?php $groupDocs = new GroupDocsAnnotation_GroupDocs(); ?>
<?php echo $groupDocs->renderFrame(); ?>
```

Also you can override default params like:
```php
<?php $groupDocs1 = new GroupDocsAnnotation_GroupDocs(array( 'fileId' => '123', 'frameborder' => '1', 'width' => '680', 'height' => '900' )); ?>
<?php echo $groupDocs1->renderFrame(); ?>
```

How to get [Document ID (GUID)](http://groupdocs.com/docs/pages/viewpage.action?pageId=1409575)

#### For configure default params login as admin and go to "Extras" => "Configure GroupDocs Annotation"  menu.

###[Sign, Manage, Annotate, Assemble, Compare and Convert Documents with GroupDocs](http://groupdocs.com)
* [Annotate PDF, Word, Excel, Powerpoint and Images with GroupDocs Annotation](http://groupdocs.com/apps/annotation)
* [DOC, DOCX, PDF Annotation in your PimCore CMS website] (http://www.pimcore.org/resources/extensions/detail/GroupDocsAnnotation)
* [See source code for GroupDocs Annotation plugin for PimCore CMS](https://github.com/groupdocs/pimcore-groupdocs-annotation-source)

###Created by [GroupDocs Marketplace Team](http://groupdocs.com/marketplace/).