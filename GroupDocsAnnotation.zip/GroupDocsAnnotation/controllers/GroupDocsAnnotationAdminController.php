<?php

class GroupDocsAnnotation_GroupDocsAnnotationAdminController extends Pimcore_Controller_Action_Admin {
	/**
	 * Return current values as json
	 */
	public function loaddataAction(){
		$this->_helper->viewRenderer->setNoRender();
		$conf = new GroupDocsAnnotation_GroupDocs();
		$this->_helper->json(
            array(
                    'id' => '1',
                    'fileId' => $conf->getConfig('fileId'),
                    'frameborder' => $conf->getConfig('frameborder'),
                    'width' => $conf->getConfig('width'),
                    'height' => $conf->getConfig('height')
            )
		);
	}

	/**
	 * Save new values
	 */
	public function savedataAction(){
		$conf = new GroupDocsAnnotation_GroupDocs();

		$fileId = $this->_getParam("fileId");
		$frameborder = $this->_getParam("frameborder");
		$width = $this->_getParam("width");
		$height = $this->_getParam("height");
		if ($fileId != '' && $frameborder != '' && $width != '' && $height != '') {
			$conf->setConfig(array( 'fileId' => $fileId, 'frameborder' => $frameborder, 'width' => $width, 'height' => $height ));
			$this->getResponse()->setHttpResponseCode(200);
		}
		else {
			$this->getResponse()->setHttpResponseCode(500);
			$this->view->message = 'Save error';
		}
		$this->_helper->viewRenderer->setNoRender();
	}
}