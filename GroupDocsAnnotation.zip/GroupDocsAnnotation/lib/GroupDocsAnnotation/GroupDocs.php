<?php
class GroupDocsAnnotation_GroupDocs {
	/**
	 * Table object
	 */
	protected $_config = null;

	/**
	 * GroupDocs file ID
	 */
	protected $_fileId = 0;

	/**
	 * Html frame border
	 */
	protected $_frameborder = 0;

	/**
	 * Html frame width
	 */
	protected $_width = 0;

	/**
	 * Html frame height
	 */
	protected $_height = 0;

	/**
	 * Class constructor
	 * @param Array $config
	 */
	public function __construct($config = array()) {
		$this->_config = new GroupDocsAnnotation_Config();
		// Set file ID
		$this->_fileId = (empty($config['fileId'])) ? json_decode($this->getConfig('data'), true)['fileId'] : $config['fileId'];
		// Set frameborder
		$this->_frameborder = (empty($config['frameborder'])) ? $this->getConfig('frameborder') : $config['frameborder'];
		// Set width
		$this->_width = (empty($config['width'])) ? $this->getConfig('width') : $config['width'];
		// Set height
		$this->_height = (empty($config['height'])) ? $this->getConfig('height') : $config['height'];
	}

	public function getConfig($key = null) {
		try {
			$rows = $this->_config->fetchAll();
		} catch (Zend_Db_Exception $e) {
			Logger::error("Failed to get configuration; ".$e->getMessage());
			return null;
		}
		for ($n = 0; $n < count($rows); $n += 1) {
			if ($rows[$n]['id'] == 2) {
				return $rows[$n][$key];
			}
		}
		return null;
	}

	public function setConfig($values = array()) {
		$this->_config->update($values, 'id = 2');
	}

	/**
	 * Render html frame
	 */
	public function renderFrame() {
		return '<iframe src="https://apps.groupdocs.com/document-annotation/Embed/'
				. $this->_fileId
				. '?quality=50&use_pdf=True&download=False&referer=PimCore-Annotation/1.0.0" frameborder="'
				. $this->_frameborder
				. '" width="'
				. $this->_width
				. '" height="'
				. $this->_height
				. '">If you can see this text, your browser does not support iframes. Please enable iframe support in your browser or use the latest version of any popular web browser such as Mozilla Firefox or Google Chrome. For more help, please check our documentation Wiki: <a href="http://groupdocs.com/docs/display/annotation/GroupDocs+Annotation+Integration+with+3rd+Party+Platforms">http://groupdocs.com/docs/display/annotation/GroupDocs+Annotation+Integration+with+3rd+Party+Platforms</a></iframe>';
	}
}